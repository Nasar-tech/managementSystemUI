import { StudentData } from './student-data';

describe('StudentData', () => {
  it('should create an instance', () => {
    expect(new StudentData()).toBeTruthy();
  });
});
