export class StudentData {
    constructor(public id:string,public firstName:string,public lastName:string,
            public gender:string,public qualification:string,
            public percentage:string,public passout:string,
            public address:string,public number:string,public email:string){}
}
