import { BatchData } from './batch-data';

describe('BatchData', () => {
  it('should create an instance', () => {
    expect(new BatchData()).toBeTruthy();
  });
});
