export class BatchData {
    constructor(public batchId:string,public courseName:string,public facultyName:string,public durationInDays:string){}
}
