export class Facultydata {
    constructor(
        public id:string,
        public facultyName:string,
        public email:string,
        public password:string,
        public number:string,
        public allotedBatches:string
    ){}
}

