import { Facultydata } from './facultydata';

describe('Facultydata', () => {
  it('should create an instance', () => {
    expect(new Facultydata()).toBeTruthy();
  });
});
